package com.io.phonebook.dao;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;

import com.io.phonebook.domain.PhoneBook;


public class PhoneDaoImpl implements PhoneDao {
	

	public void addEntry1(PhoneBook pb) {
		PhoneBook p = new PhoneBook();
		p.setId(pb.getId());
		p.setName(pb.getName());
		p.setPhonenumber(pb.getPhonenumber());
		p.setDob(pb.getDob());
		
	}

	public void updateEntry1(PhoneBook pb) {
		PhoneBook p =null; //l1.get(pb.getId());
		PhoneBook p1=p;
		p1.setName(pb.getName());
		p1.setDob(pb.getDob());
		p1.setPhonenumber(pb.getPhonenumber());

		

	}

	public PhoneBook getEntryById(int id) {
		PhoneBook p=null;
		return p;
	}

	public PhoneBook getEntryByName1(String name) {
		PhoneBook p=null;
		return p;
	}

	@Override
	public com.io.phonebook.domain.PhoneBook getEntryByPhoneNumber(String phonenumber) {
		PhoneBook p=null;
		return p;
	}

	public List<PhoneBook> getAllEntry1() {
		List<PhoneBook> l1 = null;
	
		return l1;
	}

	@Override
	public void addPhoneBook(com.io.phonebook.domain.PhoneBook pb) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int updatePhoneBook(com.io.phonebook.domain.PhoneBook pb) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void deletePhoneBook(int pb) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Collection<com.io.phonebook.domain.PhoneBook> showAllRecord() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public com.io.phonebook.domain.PhoneBook getPhoneBookById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<com.io.phonebook.domain.PhoneBook> seachRecords(com.io.phonebook.domain.PhoneBook pb) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public LocalDate getAllEntry() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addEntry(com.io.phonebook.domain.PhoneBook pb) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateEntry(com.io.phonebook.domain.PhoneBook pb) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public com.io.phonebook.domain.PhoneBook getEntryByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}
	}