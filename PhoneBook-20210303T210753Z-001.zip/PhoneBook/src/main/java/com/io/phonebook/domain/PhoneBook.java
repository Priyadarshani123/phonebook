package com.io.phonebook.domain;

import java.time.LocalDate;

public class PhoneBook {

	private int id;
	private String name;
	private String phonenumber;
	private LocalDate dob;

	public PhoneBook() {
	}

	public PhoneBook(int id, String name, String phonenumber, LocalDate dob) {
		this.id = id;
		this.name = name;
		this.phonenumber = phonenumber;
		this.dob = dob;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	@Override
	public String toString() {
		return "PhoneBook [id=" + id + ", name=" + name + ", phonenumber=" + phonenumber + ", dob=" + dob + "]";
	}

	public void setPhoneNumber(String phoneNo) {
		// TODO Auto-generated method stub
		
	}

	public int getPhoneNumber() {
		// TODO Auto-generated method stub
		return 0;
	}

}