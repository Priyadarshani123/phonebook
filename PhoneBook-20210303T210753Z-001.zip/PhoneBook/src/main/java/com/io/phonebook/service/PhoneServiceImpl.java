package com.io.phonebook.service;


import java.time.LocalDate;
import java.util.Collection;
import java.util.Scanner;

import com.io.phonebook.dao.PhoneDaoImpl;
import com.io.phonebook.domain.PhoneBook;


	public class PhoneServiceImpl implements PhoneService {

		PhoneDaoImpl pbDao = new PhoneDaoImpl();

		@Override
		public void addPhoneBook()  {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the name");
			String name = sc.next();
			System.out.println("Enter the Phone No");
			String phoneNo = sc.next();
			System.out.println("Enter Date of Birth yyyy-mm-dd");
			String db = sc.next();
			LocalDate date = LocalDate.parse(db);
			System.out.println("Local Date is::::" + date);

			PhoneBook pb = new PhoneBook();
			pb.setName(name);
			pb.setPhoneNumber(phoneNo);
			// pb.setDob(date);

			System.out.println(pb.toString());
			pbDao.addPhoneBook(pb);

			System.out.println("Added Successfully");

		}

		@Override
		public void updatePhoneBook() {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the Id for Update::");
			int id = sc.nextInt();
			PhoneBook pb = pbDao.getPhoneBookById(id);

			System.out.println(pb);
			if (pb != null) {
				System.out.println("Enter the name");
				String name = sc.next();
				System.out.println("Enter the Phone No");
				String phoneNo = sc.next();

				pb.setName(name);
				pb.setPhoneNumber(phoneNo);

				pbDao.updatePhoneBook(pb);
			} else {
				System.out.println("Data not found with this id");
			}

		}

		@Override
		public void deletePhoneBook()  {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the Id for DELETE::");
			int id = sc.nextInt();
			PhoneBook pb = pbDao.getPhoneBookById(id);

			System.out.println(pb);
			if (pb != null) {

				pbDao.deletePhoneBook(id);

			} else {
				System.out.println("Date not found with this id");
			}
		}

		@Override
		public void showAllRecord()  {
			Collection<PhoneBook> pbCollection = pbDao.showAllRecord();
			System.out.println(" ID:\t\tName:\t\tPhoneNo:\t\tDOB:");
			if (pbCollection.size() == 0) {
				System.out.println("0 RECORDS FOUND");
			}
			for (PhoneBook pb : pbCollection) {
				System.out
						.println(pb.getId() + "\t\t" + pb.getName() + "\t\t" + pb.getPhoneNumber() + "\t\t" + pb.getDob());
			}
		}

		@Override
		public void searchRecods()  {
			Scanner sc = new Scanner(System.in);
			System.out.println("SEARCH:::Enter the name ");
			String name = sc.next();
			System.out.println("SEARCH:::Enter the Phone No");
			String phoneNo = sc.next();
			System.out.println("SEARCH:::Enter Date of Birth yyyy-mm-dd");
			String db = sc.next();
			LocalDate date = LocalDate.parse(db);
			System.out.println("Local Date is::::" + date);

			PhoneBook pb = new PhoneBook();
			pb.setName(name);
			pb.setPhoneNumber(phoneNo);
			// pb.setDob(date);

			System.out.println(pb.toString());
			Collection<PhoneBook> pbCollection = pbDao.seachRecords(pb);

			System.out.println(" ID:\t\tName:\t\tPhoneNo:\t\tDOB:");
			if (pbCollection.size() == 0) {
				System.out.println("0 RECORDS FOUND");
			}
			for (PhoneBook rec : pbCollection) {
				System.out.println(
						rec.getId() + "\t\t" + rec.getName() + "\t\t" + rec.getPhoneNumber() + "\t\t" + rec.getDob());
			}
		}

	}
