package com.io.phonebook.service;

public interface PhoneService {

		public void addPhoneBook() ;

		public void updatePhoneBook();

		public void deletePhoneBook();
		
		public void showAllRecord();

		public void searchRecods() ;
	}
