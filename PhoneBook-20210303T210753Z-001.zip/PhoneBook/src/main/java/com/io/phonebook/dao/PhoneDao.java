package com.io.phonebook.dao;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;

import com.io.phonebook.domain.PhoneBook;

public interface PhoneDao {
	
	public void addPhoneBook(PhoneBook pb) ;

	public int updatePhoneBook(PhoneBook pb) ;

	public void deletePhoneBook(int pb);
	
	public Collection<PhoneBook> showAllRecord();
	
	public PhoneBook getPhoneBookById(int id);

	public List<PhoneBook> seachRecords(PhoneBook pb) ;

	LocalDate getAllEntry();

	PhoneBook getEntryByPhoneNumber(String phonenumber);

	void addEntry(PhoneBook pb);

	void updateEntry(PhoneBook pb);

	PhoneBook getEntryByName(String name);
}




