package com.io.phonebook.main;


import java.util.Scanner;

import com.io.phonebook.resources.ReadJsonFile;
import com.io.phonebook.service.PhoneService;
import com.io.phonebook.service.PhoneServiceImpl;

public class PhoneBookMain {

	public static void main(String[] args)  {
		PhoneService phoneBookService = new PhoneServiceImpl();
		ReadJsonFile loginJson = new ReadJsonFile();
		System.out.println("Phone Book");
		System.out.println("1. Add PhoneBook Entry:");
		System.out.println("2. Update PhoneBook Entry");
		System.out.println("3. Delete PhoneBook Entry");
		System.out.println("4. Show PhoneBook Entries");
		System.out.println("5. Search PhoneBook Entry by Name and PhoneNO");
		System.out.println("--------------------------------------");
		System.out.println("10. Press 0 to exit the system");

		Scanner sc = new Scanner(System.in);

		boolean flag = true;
		while (flag) {
			System.out.println("Enter your choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				if (loginJson.checkCredentials()) {
					phoneBookService.addPhoneBook();
				} else {
					System.out.println("Invalid Credentials");
				}
				break;
			case 2:
				if (loginJson.checkCredentials()) {
					phoneBookService.updatePhoneBook();
				} else {
					System.out.println("Invalid Credentials");
				}

				break;
			case 3:
				if (loginJson.checkCredentialsAdmin()) {
					phoneBookService.deletePhoneBook();
				} else {
					System.out.println("Invalid Credentials/ Onlu Admin Can delete Data");
				}

				break;
			case 4:
				if (loginJson.checkCredentials()) {
					phoneBookService.showAllRecord();
				} else {
					System.out.println("Invalid Credentials");

				}
				break;
			case 5:
				if (loginJson.checkCredentials()) {
					phoneBookService.searchRecods();
				} else {
					System.out.println("Invalid Credentials");
				}
				break;
			case 0:
				flag = false;
				System.out.println("Welcome Again!!!");
				System.exit(0);
				break;

			default:
				System.out.println("Enter valid choice");
				break;
			}
		}

	}
}