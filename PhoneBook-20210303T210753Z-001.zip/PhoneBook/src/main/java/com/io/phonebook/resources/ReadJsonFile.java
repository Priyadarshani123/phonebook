package com.io.phonebook.resources;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.io.phonebook.domain.Users;

public class ReadJsonFile {

	Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		ReadJsonFile rj = new ReadJsonFile();
		Map<Integer, Users> data = rj.readData();
		System.out.println("Data::" + data);
		displayData.accept(data);
	}

	public boolean checkCredentials() {
		System.out.println("Enter Username:");
		String username = sc.next();
		System.out.println("Enter Password:");
		String password = sc.next();
		ReadJsonFile rj = new ReadJsonFile();
		Map<Integer, Users> data = rj.readData();
		boolean flag = false;
		for (Users user : data.values()) {
			System.out.println("user in list:" + user);
			if (user.getLoginName().equalsIgnoreCase(username) && user.getPassword().equalsIgnoreCase(password)) {
				flag = true;
			}
		}
		return flag;

	}
	
	public boolean checkCredentialsAdmin() {
		System.out.println("Enter Username:");
		String username = sc.next();
		System.out.println("Enter Password:");
		String password = sc.next();
		ReadJsonFile rj = new ReadJsonFile();
		Map<Integer, Users> data = rj.readData();
		boolean flag = false;
		for (Users user : data.values()) {
			System.out.println("user in list:" + user);
			if (user.getLoginName().equalsIgnoreCase(username) && user.getPassword().equalsIgnoreCase(password) && user.getRole().equalsIgnoreCase("admin")) {
				flag = true;
			}
		}
		return flag;

	}

	Function<String, File> fileReader = fname -> {
		System.out.println(fname);
		ClassLoader cl = getClass().getClassLoader();
		File loginJson = new File(cl.getResource(fname).getFile());
		return loginJson;
		// return new File(getClass().getClassLoader().getResource(fname).getFile());
	};

	static Consumer<Map<Integer, Users>> displayData = emp -> {
		emp.forEach((k, v) -> System.out.println(k + " Users :" + v));
	};

	Function<JSONObject, Integer> idData = json -> Integer.parseInt((String) json.get("id"));

	Function<JSONObject, Users> fetchUser = json -> {
		Users u = new Users();
		// u.setId(Integer.parseInt((String) json.get("id")));
		u.setFirstame((String) json.get("firstame"));
		u.setLastname((String) json.get("lastname"));
		u.setEmail((String) json.get("email"));
		u.setMobile((String) json.get("mobile"));
		u.setLoginName((String) json.get("loginName"));
		u.setPassword((String) json.get("password"));
		u.setStatus((String) json.get("status"));
		u.setRole((String) json.get("role"));

		return u;

	};

	Map<Integer, Users> readData() {
		// File file = fileReader.apply("login.json");
		// System.out.println("FIle is ::" + file);
		FileReader r = null;
		try {
			r = new FileReader(".\\Json Files\\login.json");
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		JSONParser parser = new JSONParser();
		Map<Integer, Users> users = null;
		try (Reader reader = r) {
			JSONArray jArray = (JSONArray) parser.parse(reader);
			System.out.println("JSONArray:::" + jArray);

			users = (Map<Integer, Users>) jArray.stream().collect(Collectors.toMap(idData, fetchUser));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return users;
	}

}
